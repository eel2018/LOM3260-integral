# importando bibliotecas
import tkinter as tk
import tkinter.messagebox as msg
from tkinter import ttk
import tkinter.filedialog as fld
from numpy import *
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
# importando arquivo que possui a função que realiza a integração
import integral as integ
import webbrowser as web

# definindo classe que será usada pra tudo
class Everything:
    
    def __init__(self,master):
        self.janela(master)
    
    # definindo função janela
    def janela(self,master):
        
        # *********  BARRA DE MENU  ********
        
        #definindo menu superior
        menu = tk.Menu()
        #definindo um submenu
        submenu = tk.Menu(menu)
        submenu = tk.Menu(menu)
        #não permite 'arrancar submenu'
        submenu = tk.Menu(menu, tearoff=0)
        root.config(menu = menu)

        # definindo nomes dos menus e os comandos à eles associados
        menu.add_command(label='Salvar...',command= self.salvar_arquivo)
        menu.add_cascade(label='Help',menu= submenu)
        submenu.add_command(label='Nosso site...',command= self.openweb)
        submenu.add_command(label='Manual...',command= self.abre_manual)
        submenu.add_command(label='Tutorial...',command= self.tutorial)
        submenu.add_command(label='Termos de Uso',command= self.termos)
        menu.add_command(label='Sobre...',command= self.mostrar_info)
        
        #*******  FRAME  *********    
        # definindo frames
        self.frame= None    
        frameGrafico= ttk.Frame()
        frameEntrada= ttk.Frame()
        #definindo localização dos frames
        frameGrafico.pack(side='left')
        frameEntrada.pack(side='right')
        
        #*******    ROTULOS  ***** 
        # definindo textos que aparecerão na janela
        care=ttk.Label(frameEntrada,text='Funciona somente com a incógnita x!')   
        f=ttk.Label(frameEntrada,text='f(x):')
        intA=ttk.Label(frameEntrada,text='A:')
        intB=ttk.Label(frameEntrada,text='B:')
        resp=tk.Label(frameEntrada,text="Valor da integral =")
        title=ttk.Label(frameEntrada,text='Título:')
        eixox=ttk.Label(frameEntrada,text='Eixo x:')
        eixoy=ttk.Label(frameEntrada,text='Eixo y:')
        
        # definindo onde esses textos aparecerão, row = linha, column = coluna)
        f.grid(row=1,column=1,sticky='W',padx=10,pady=10)
        intA.grid(row=2,column=1,sticky='W',padx=10,pady=10)
        intB.grid(row=2,column=2,sticky='W',padx=10,pady=10)
        resp.grid(row=3,column=2,sticky='W',padx=10,pady=10)
        care.grid(row=1,column=2,sticky='W',padx=10,pady=10)
        title.grid(row=4,column=1,sticky='W',padx=10,pady=10)
        eixox.grid(row=5,column=1,sticky='W',padx=10,pady=10)
        eixoy.grid(row=6,column=1,sticky='W',padx=10,pady=10)
        
        # valor da integral
        self.valor_integ=tk.Label(frameEntrada,text='')
        # definindo onde o valor da integral irá aparecer
        self.valor_integ.grid(row=3,column=2,sticky='W',padx=120,pady=10)
        
        #*******    CAMPO DE ENTRADA  *****
        # definindo variáveis
        self.F = tk.StringVar()
        self.A = tk.StringVar()
        self.B = tk.StringVar()
        self.título = tk.StringVar()
        self.eixox = tk.StringVar()
        self.eixoy = tk.StringVar()
        self.valor = tk.StringVar() 
        self.Cria_Grafico(frameGrafico)
        
        #definindo barra onde serão obtidas algumas das variáveis acima
        eF=ttk.Entry(frameEntrada,textvariable=self.F)
        eA=ttk.Entry(frameEntrada,textvariable=self.A)
        eB=ttk.Entry(frameEntrada,textvariable=self.B)
        eX=tk.Entry(frameEntrada,textvariable=self.eixox)
        eY=tk.Entry(frameEntrada,textvariable=self.eixoy)
        eTitle=tk.Entry(frameEntrada,textvariable=self.título)
        
        #definindo localização das barras acima
        eF.grid(row=1,column=1,sticky='W',padx=60,pady=10)
        eA.grid(row=2,column=1,sticky='W',padx=60,pady=10)
        eB.grid(row=2,column=2,sticky='W',padx=30,pady=10)
        eTitle.grid(row=4,column=1,sticky='W',padx=60,pady=10)
        eX.grid(row=5,column=1,sticky='W',padx=60,pady=10)
        eY.grid(row=6,column=1,sticky='W',padx=60,pady=10)
        
        #******  BOTAO  *********
        # definindo botões
        BI=ttk.Button(frameEntrada,text='Integrar',command= self.Mostra_valor)
        BQ=ttk.Button(frameEntrada,text='Sair',command= self.Destroy)
        
        #definindo posicionamento dos botões acima
        BI.grid(row=3,column=1,padx=10,pady=10)
        BQ.grid(row=7,columnspan=7,padx=10,pady=10)
        
        #******  KEYBINDING  *********
        # definindo keybindings
        #pressionar a tecla 'enter' integra a função
        eF.bind("<Return>", lambda event: self.Mostra_valor())
        eA.bind("<Return>", lambda event: self.Mostra_valor())
        eB.bind("<Return>", lambda event: self.Mostra_valor())
        eX.bind("<Return>", lambda event: self.Mostra_valor())
        eY.bind("<Return>", lambda event: self.Mostra_valor())
        
        # fecha o programa ao pressionar ESC
        root.bind('<Escape>', lambda event: self.Destroy())
        
        # executa a função Destroy ao clicar no botão 'x' da janela
        root.protocol("WM_DELETE_WINDOW", self.Destroy)
        
    # definindo função que salva imagem do gráfico
    def salvar_arquivo(self):
        formatos = ( ("formato png","*.png"),("formato jpg","*.jpg") )
        filename = fld.asksaveasfilename(initialdir = "./",title = "Exportando a figura...",filetypes = formatos)
        if filename is not '' and filename is not ():
            plt.savefig(filename)


    # definindo função quer abre página do projeto no github
    def openweb(self):
         new = 1
         url = "https://github.com/eel2018/LOM3260-integral"
         web.open(url,new=new)
         
    # definindo função de mostrar mensagem de informação
    def mostrar_info(self):
        about_text = '''
        
              Python Integrator
        
              LOM3260 - Computação Científica em Python
        
              Engenharia Física
        
              EEL-USP 2018
             '''
        # título "Info", mensagem referenciada como about_text
        msg.showinfo('Info', about_text)
    
    # definindo função que abre o manual
    def abre_manual(self):
        new = 1
        url = "https://github.com/eel2018/LOM3260-integral/raw/master/Manual%20de%20uso.docx"
        web.open(url,new=new)
    
    def termos(self):
        about_text = '''
Termos de Uso
              
              Este programa é uma ferramenta para cálculo de integrais definidas e indefinidas. Trata-se de um software desenvolvido em Python, cuja programação contém bibliotecas que permitem ao usuário não só o acesso aos resultados como também a gráficos. Salienta-se que o programa não demonstra passo a passo as resoluções, apenas a resposta final é fornecida.
              O Python Integrator não se responsabiliza pela veracidade dos dados, embora assegure serem de grande exatidão. Também não cabe ao software, a responsabilidade por estudos, trabalhos ou provas realizadas pelo usuário. Desta forma, o usuário deve estar ciente de que o conferimento dos dados digitados para cálculo de integrais e dos resultados fornecidos pelo programa, cabe a si.
              Sendo a lei n°9.609, de 19 de fevereiro de 1998, que dispõe sobre a proteção da propriedade de programa de computador, sua comercialização no País, e dá outras providências; declaram-se desenvolvedores deste programa: Arnon Costa, Bianca da Costa Deangelo, Gabriel Costa, Guilherme Lucchesi Alves Balio, Guilherme Aloise Pedrini, Larissa Guermandi Zambon, Lucas Santos Souza e Raphaela Rosa Cassimiro de Souza.
              Por fim, garante-se ao usuário o acesso gratuito ao programa, assegurando uma política de privacidade detalhada abaixo:

Politica de Privacidade 

	Nenhum dado pessoal ou profissional do usuario é/ou deve ser solicitado para o uso ou entendimento do conteúdo do Python Integrator. Todos dados coletados são numéricos e de coito academicos, unicamente para expressar o calculo requisitado. As informações descritas acima são disponibilizadas apenas ao programa, para que ocorra o calculo das integrais (solicitado pelo usuario), tais informações após o calculo são perdidas/não armazenadas pelo programa.
	O Python Integrator é gratuito e livre para qualquer faixa etária, sem utilização de cookies e utilizado para fins didáticos e academicos.

             '''
        # título "Info", mensagem referenciada como about_text
        msg.showinfo('Info', about_text)
    
    # definindo função que abre o tutorial
    def tutorial(self):
        new = 1
        url = "https://youtu.be/uaDaSQxwxjw"
        web.open(url,new=new)
    
    # definindo função quer cria gráfico usando matplotlib
    def Cria_Grafico(self, frameGrafico):
        
        # associando self.fig com a função de figura da biblioteca plt
        self.fig = plt.figure()
        # associando self.ax com eixos do gráfico
        self.ax = plt.axes()
        # definindo cor do eixo x
        plt.axhline(0, color='k')
        # definindo cor do eixo y
        plt.axvline(0, color='k')
        
        # definindo área da imagem do gráfico
        canvas = FigureCanvasTkAgg(self.fig, master=frameGrafico)
        canvas.get_tk_widget().pack()
        
    # não permite ao usuário modificar o tamanho horizontal ou vertical da janela
        root.resizable(False, False)
    
    # definindo a função que atualiza o gráfico com os valores fornecidos
    def Atualiza_grafico(self,f,a,b):
        
        # definindo limites da imagem do gráfico a partir dos limites de integração
        x0 = a - abs(a/2)
        x1 = b + abs(b/2)
        #definindo o número de pontos
        N = 100
        # definindo eixos x e y
        x = linspace(a,b,N)
        # eval tenta associar string à uma função
        y = eval(f)
        # apaga a imagem gráfico
        self.ax.cla()
        # plota valores de x e y
        plt.plot(x,y)
        # definindo os limites da imagem do gráfico
        plt.xlim(x0,x1)
    # definindo texto do título, eixo x e eixo y de acordo com variáveis associadas à texto colocado por usuário
        plt.title(self.título.get())
        plt.xlabel(self.eixox.get())
        plt.ylabel(self.eixoy.get())
        # definindo limites de y para imagem do gráfico
        plt.ylim(y.min()-abs((y.min()/5)),y.max()+abs((y.max()/5)))
        # colore região da integral
        plt.fill_between(x,y, color='red', alpha = 0.4)
        self.fig.canvas.draw_idle()

        '''
        define função que mostra o valor da integral de acordo com 
        a função e limites de integração definidas pelo usuário
        '''
    def Mostra_valor(self):
        # valores do limite de integração, necessário que sejam float
        a = float(self.A.get())      
        b = float(self.B.get())
        # função definida pelo usuário, salva na variável self.F
        f = self.F.get()
        # utiliza o aquivo 'integral' para executar a integração
        self.valor = integ.integral(f,a,b)
        # executa função Atualiza_grafico com os valores de f, a,b definidos
        self.Atualiza_grafico(f,a,b)
        # atualiza texto do valor da integral
        self.valor_integ['text'] = str(self.valor)
    
    # define função que fecha a janela
    def Destroy(self):
        # mensagem de sim/não quando a função é executada
        y = msg.askyesno('Sair', 'Deseja realmente sair? Você pode perder informações!')
        # se o usuário escolher "sim" a janela é fechada
        if y is True:
            root.destroy()

# definindo root
root = tk.Tk()
# título da janela
root.title('Python Integrator')
# associando a classe ao root
b = Everything(root)
# mainloop associado à root
root.mainloop()